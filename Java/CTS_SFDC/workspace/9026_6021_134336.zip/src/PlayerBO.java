  public class PlayerBO {
    void displayAllPlayerDetails(Player[] playerList)
	{
		System.out.println("Player Details");
		for(Player p : playerList) {
			System.out.println(p);
		}
	}

}


