package ipl;

import java.sql.SQLException;

public class TeamBO {
//    public Map<String,Integer> obtainAllTeams() throws ClassNotFoundException, SQLException{
//    	
//    	return new TeamDAO().obtainAllTeams();
//
//    }    
}
