import java.sql.SQLException;

import java.util.List;


public class PlayerBO {

	public List<Player> getAllCaptain() throws ClassNotFoundException, SQLException {

		return new PlayerDAO().getAllCaptain();
	}

	public Player getPlayerById(int id) throws ClassNotFoundException, SQLException {

		return new PlayerDAO().getPlayerById(id);
	}

	
}
