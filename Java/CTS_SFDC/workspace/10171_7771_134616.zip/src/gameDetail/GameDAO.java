package gameDetail;

import java.util.ArrayList;

public class GameDAO {

	public ArrayList<Game> listGames(int id) throws ClassNotFoundException {
		
		return new ArrayList<>();

	}
}
