package gameDetail;




public class TeamBO {
	public Team getTeamById(int id) throws ClassNotFoundException {
		
		return new Team();

	}
}
