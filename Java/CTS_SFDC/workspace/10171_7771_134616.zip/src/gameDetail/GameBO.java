package gameDetail;






public class GameBO {
}
