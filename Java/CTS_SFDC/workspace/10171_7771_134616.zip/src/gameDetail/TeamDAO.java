package gameDetail;




public class TeamDAO {

	public Team getTeamById(int id) throws ClassNotFoundException {
		
		return new Team();
	}
}
