package team;

import java.sql.SQLException;
import java.util.List;

public class TeamBO {
    public List<Team> obtainAllTeams() throws ClassNotFoundException, SQLException{
       return new TeamDAO().obtainAllTeams();
    }
	public Integer deleteTeamById(Integer id) throws ClassNotFoundException, SQLException {
	   return new TeamDAO().deleteTeamById(id);
	}
  
}

