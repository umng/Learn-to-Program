
public class Calculator {
	@Arithmetic
	void addition() {
		
	}

	@Arithmetic
	void subtraction() {
		
	}

	@Arithmetic
	void multiplication() {
		
	}

	@Arithmetic
	void division() {
		
	}

	@Scientific
	void sine() {
		
	}

	@Scientific
	void cosine() {
		
	}

	@Scientific
	void tangent() {
		
	}

	@Scientific
	void logarithm() {
		
	}
}
