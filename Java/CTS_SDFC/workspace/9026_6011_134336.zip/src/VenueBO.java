  public class VenueBO {
    
	void displayVenueDetails(Venue venue)
	{
		System.out.printf("Venue Details\n%s,%s", venue.getName(), venue.getCity());
	}

}


