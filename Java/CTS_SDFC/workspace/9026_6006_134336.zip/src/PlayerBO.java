  public class PlayerBO {
    void displayPlayerDetails(Player p)
	{
		System.out.print("Player Details\n" + p.getName() + "       " + p.getCountry() + "           " + p.getSkill());
	}

}


