  
public class InningsBO {
    
	void displayAllInningsDetails(Innings [] innings)
	{
		System.out.println("Innings Details");
		for(Innings i : innings) {
			System.out.println(i);
		}
	}

}


